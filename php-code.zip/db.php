<?php
header("Access-Control-Allow-Origin: *");
mysql_connect("localhost","root","root");
mysql_select_db("phonegap_demo");
?>